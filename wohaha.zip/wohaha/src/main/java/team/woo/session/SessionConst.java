package team.woo.session;

public interface SessionConst {

    public static final String LOGIN_MEMBER = "loginMember";
}
