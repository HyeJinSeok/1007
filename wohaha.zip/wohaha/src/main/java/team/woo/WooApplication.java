package team.woo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WooApplication {

    public static void main(String[] args) {
        SpringApplication.run(WooApplication.class, args);
    }

}
